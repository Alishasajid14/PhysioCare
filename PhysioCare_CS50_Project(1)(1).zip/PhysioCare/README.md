# PhysioCare – Physiotherapy Exercise Planner

## Video Demo
Add the URL of your own video demonstration here after recording and uploading it.

## Description
PhysioCare is a Flask-based educational physiotherapy exercise planner. Users can browse general exercise examples by body area, search the exercise list, read step-by-step instructions, and add exercises to a daily checklist. Checklist selections and completion ticks are saved in the browser using local storage.

The project demonstrates a Python Flask backend, JSON API, HTML templates, CSS styling, JavaScript interaction, and browser-side data persistence.

## Features
- Browse exercises for the neck, shoulder, back, elbow, wrist, hip, knee, and ankle.
- Filter by body area and search by exercise name or purpose.
- Open an exercise detail window with instructions, suggested practice amount, and cautions.
- Add or remove exercises from a personal checklist.
- Mark checklist items as complete and view a progress bar.
- Save the checklist in the browser's local storage.

## Files
- `app.py`: Flask application, sample exercise data, home page route, and JSON API.
- `templates/index.html`: Page structure and user interface.
- `static/style.css`: Responsive design and visual styling.
- `static/script.js`: Filtering, exercise details, checklist, and local storage behavior.
- `requirements.txt`: Python dependency list.
- `README.md`: Project documentation.

## How to Run
1. Install Python 3.10 or newer.
2. Open a terminal in the project folder.
3. Install dependencies: `pip install -r requirements.txt`
4. Start the application: `python app.py`
5. Open `http://127.0.0.1:5000` in a browser.

## Design
Flask serves the main HTML page and exposes `/api/exercises`, which returns exercise information as JSON. JavaScript requests that API, applies the selected filters, and creates the exercise cards. The checklist is stored in browser local storage, so it remains available in the same browser on the same device.

## Safety
This is an educational student project, not a clinical decision tool or personalized treatment plan. The sample exercises are general examples and may not be suitable for every person or condition. Users should seek advice from a qualified healthcare professional before starting exercises, especially after injury or surgery. Stop if symptoms worsen. The app does not diagnose conditions or replace professional assessment.

## Future Improvements
Possible additions include user accounts, clinician-approved personalized plans, demonstration videos, reminders, and progress history.
