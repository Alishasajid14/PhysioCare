const areaFilter = document.getElementById("area-filter");
const searchInput = document.getElementById("search-input");
const exerciseList = document.getElementById("exercise-list");
const resultCount = document.getElementById("result-count");
const checklist = document.getElementById("checklist");
const progressText = document.getElementById("progress-text");
const progressBar = document.getElementById("progress-bar");
const dialog = document.getElementById("exercise-dialog");

let exercises = [];
let selected = JSON.parse(localStorage.getItem("physiocare-selected") || "[]");
let completed = JSON.parse(localStorage.getItem("physiocare-completed") || "[]");

async function loadExercises() {
  const params = new URLSearchParams({
    area: areaFilter.value,
    q: searchInput.value.trim()
  });
  exerciseList.innerHTML = '<p class="loading">Loading exercises…</p>';
  try {
    const response = await fetch(`/api/exercises?${params}`);
    if (!response.ok) throw new Error("Could not load exercises");
    exercises = await response.json();
    renderExercises();
  } catch (error) {
    exerciseList.innerHTML = '<p class="empty">Could not load exercises. Please refresh the page.</p>';
    resultCount.textContent = "Unavailable";
  }
}

function renderExercises() {
  resultCount.textContent = `${exercises.length} exercise${exercises.length === 1 ? "" : "s"}`;
  if (!exercises.length) {
    exerciseList.innerHTML = '<p class="empty">No exercises found. Try another body area or search.</p>';
    return;
  }
  exerciseList.innerHTML = exercises.map(item => `
    <article class="exercise-card">
      <span class="area-pill">${escapeHTML(item.area)}</span>
      <h3>${escapeHTML(item.name)}</h3>
      <p>${escapeHTML(item.purpose)}</p>
      <div class="card-actions">
        <button class="button button-primary" data-details="${item.id}">View details</button>
        <button class="button button-light" data-add="${item.id}">${selected.includes(item.id) ? "Added ✓" : "Add to plan"}</button>
      </div>
    </article>
  `).join("");

  exerciseList.querySelectorAll("[data-details]").forEach(button => {
    button.addEventListener("click", () => showDetails(button.dataset.details));
  });
  exerciseList.querySelectorAll("[data-add]").forEach(button => {
    button.addEventListener("click", () => toggleSelected(button.dataset.add));
  });
}

function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, char => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;"
  })[char]);
}

function showDetails(id) {
  const item = exercises.find(ex => ex.id === id);
  if (!item) return;
  document.getElementById("modal-area").textContent = item.area;
  document.getElementById("modal-title").textContent = item.name;
  document.getElementById("modal-purpose").textContent = item.purpose;
  document.getElementById("modal-steps").innerHTML = item.instructions.map(step => `<li>${escapeHTML(step)}</li>`).join("");
  document.getElementById("modal-dosage").textContent = item.dosage;
  document.getElementById("modal-caution").textContent = item.caution;
  dialog.showModal();
}

function toggleSelected(id) {
  selected = selected.includes(id) ? selected.filter(item => item !== id) : [...selected, id];
  completed = completed.filter(item => selected.includes(item));
  saveState();
  renderExercises();
  renderChecklist();
}

function saveState() {
  localStorage.setItem("physiocare-selected", JSON.stringify(selected));
  localStorage.setItem("physiocare-completed", JSON.stringify(completed));
}

function renderChecklist() {
  const chosen = selected.map(id => allExerciseCache.find(item => item.id === id)).filter(Boolean);
  if (!chosen.length) {
    checklist.innerHTML = '<p class="muted">Add exercises from the exercise cards to build your checklist.</p>';
  } else {
    checklist.innerHTML = chosen.map(item => `
      <label class="check-row ${completed.includes(item.id) ? "done" : ""}">
        <input type="checkbox" data-complete="${item.id}" ${completed.includes(item.id) ? "checked" : ""}>
        <span>${escapeHTML(item.name)} <small>· ${escapeHTML(item.area)}</small></span>
      </label>
    `).join("");
    checklist.querySelectorAll("[data-complete]").forEach(box => {
      box.addEventListener("change", () => {
        const id = box.dataset.complete;
        completed = box.checked ? [...completed, id] : completed.filter(item => item !== id);
        saveState();
        renderChecklist();
      });
    });
  }
  const done = chosen.filter(item => completed.includes(item.id)).length;
  progressText.textContent = `${done} / ${chosen.length} completed`;
  progressBar.style.width = chosen.length ? `${done / chosen.length * 100}%` : "0%";
}

let allExerciseCache = [];
async function loadAllForChecklist() {
  try {
    const response = await fetch("/api/exercises");
    allExerciseCache = await response.json();
    renderChecklist();
  } catch (error) {
    checklist.innerHTML = '<p class="muted">Checklist is temporarily unavailable.</p>';
  }
}

areaFilter.addEventListener("change", loadExercises);
searchInput.addEventListener("input", loadExercises);
document.getElementById("close-dialog").addEventListener("click", () => dialog.close());
document.getElementById("reset-button").addEventListener("click", () => {
  completed = [];
  saveState();
  renderChecklist();
});

loadAllForChecklist();
loadExercises();
