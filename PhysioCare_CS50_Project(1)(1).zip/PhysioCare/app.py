from flask import Flask, render_template, jsonify, request

app = Flask(__name__)

# General educational examples only. These are not individualized treatment plans.
EXERCISES = [
    {
        "id": "neck-turns",
        "area": "Neck",
        "name": "Gentle Neck Rotation",
        "purpose": "Practise comfortable neck movement.",
        "instructions": ["Sit upright with your shoulders relaxed.", "Slowly turn your head to one side without forcing it.", "Return to the centre, then repeat on the other side."],
        "dosage": "Try 3–5 comfortable repetitions per side.",
        "caution": "Stop if you feel pain, dizziness, tingling, or worsening symptoms."
    },
    {
        "id": "shoulder-rolls",
        "area": "Shoulder",
        "name": "Shoulder Rolls",
        "purpose": "Encourage gentle shoulder movement.",
        "instructions": ["Sit or stand comfortably.", "Slowly roll both shoulders forwards.", "Then roll them backwards, keeping the movement comfortable."],
        "dosage": "Try 5 slow circles in each direction.",
        "caution": "Do not force the movement or continue through pain."
    },
    {
        "id": "pendulum",
        "area": "Shoulder",
        "name": "Supported Pendulum",
        "purpose": "Practise a small, relaxed shoulder movement.",
        "instructions": ["Use a sturdy table for support with your unaffected hand.", "Let the other arm hang comfortably.", "Gently shift your body so the arm makes a small movement."],
        "dosage": "Try 20–30 seconds only if a clinician has advised this exercise.",
        "caution": "Not suitable for every shoulder injury or post-operative stage. Follow your clinician's instructions."
    },
    {
        "id": "seated-back-extension",
        "area": "Back",
        "name": "Seated Posture Reset",
        "purpose": "Practise a comfortable upright sitting position.",
        "instructions": ["Sit with both feet supported.", "Gently lengthen your spine and relax your shoulders.", "Breathe normally and avoid arching forcefully."],
        "dosage": "Hold for 5–10 seconds; repeat 3 times if comfortable.",
        "caution": "Stop if symptoms increase. This is a posture practice, not a treatment for back pain."
    },
    {
        "id": "wrist-circles",
        "area": "Wrist",
        "name": "Wrist Circles",
        "purpose": "Move the wrist gently through a comfortable range.",
        "instructions": ["Rest your forearm on a table.", "Make small, slow circles with your wrist.", "Change direction."],
        "dosage": "Try 5 circles in each direction.",
        "caution": "Avoid this if it aggravates pain, swelling, numbness, or tingling."
    },
    {
        "id": "elbow-bend",
        "area": "Elbow",
        "name": "Elbow Bend and Straighten",
        "purpose": "Practise comfortable elbow movement.",
        "instructions": ["Keep your upper arm close to your side.", "Slowly bend your elbow.", "Slowly straighten it again without locking or forcing it."],
        "dosage": "Try 5–8 comfortable repetitions.",
        "caution": "Follow medical advice after fracture, surgery, or acute injury."
    },
    {
        "id": "seated-knee-extension",
        "area": "Knee",
        "name": "Seated Knee Straightening",
        "purpose": "Practise active knee movement while seated.",
        "instructions": ["Sit on a stable chair with your feet on the floor.", "Slowly straighten one knee as far as comfortable.", "Lower your foot slowly and repeat on the other side."],
        "dosage": "Try 5 repetitions per side if comfortable.",
        "caution": "Do not force the knee or exercise through sharp pain or new swelling."
    },
    {
        "id": "ankle-pumps",
        "area": "Ankle",
        "name": "Ankle Pumps",
        "purpose": "Move the ankle gently up and down.",
        "instructions": ["Sit or lie with your leg supported.", "Point your toes gently away from you.", "Bring your toes gently back towards you."],
        "dosage": "Try 10 slow repetitions if comfortable.",
        "caution": "New one-sided calf swelling, warmth, redness, or unexplained pain needs urgent medical assessment; do not use exercise as a substitute."
    },
    {
        "id": "hip-march",
        "area": "Hip",
        "name": "Seated Marching",
        "purpose": "Practise gentle hip movement while seated.",
        "instructions": ["Sit upright on a stable chair.", "Lift one foot a small distance from the floor.", "Lower it slowly and repeat with the other leg."],
        "dosage": "Try 5 repetitions per side.",
        "caution": "Stop if you experience pain, instability, or dizziness."
    }
]

AREAS = sorted({item["area"] for item in EXERCISES})

@app.route("/")
def index():
    return render_template("index.html", areas=AREAS)

@app.get("/api/exercises")
def get_exercises():
    area = request.args.get("area", "").strip().lower()
    search = request.args.get("q", "").strip().lower()
    results = EXERCISES
    if area and area != "all":
        results = [item for item in results if item["area"].lower() == area]
    if search:
        results = [
            item for item in results
            if search in item["name"].lower()
            or search in item["purpose"].lower()
            or search in item["area"].lower()
        ]
    return jsonify(results)

@app.get("/health")
def health():
    return jsonify({"status": "ok"})

if __name__ == "__main__":
    app.run(debug=True)
